package com.example.music_player

import android.app.RecoverableSecurityException
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Size
import com.ryanheise.audioservice.AudioServiceActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors

private const val VOFF = 4000000000000L

class MainActivity : AudioServiceActivity() {
    private var channel: MethodChannel? = null
    private var pendingDelete: MethodChannel.Result? = null
    private var pendingUri: Uri? = null
    private val pool = Executors.newFixedThreadPool(2)

    private fun uriFor(id: Long): Uri =
        if (id >= VOFF) ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id - VOFF)
        else ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)

    private fun loadArt(id: Long, px: Int): ByteArray? {
        val uri = uriFor(id)
        var bmp: Bitmap? = null
        try {
            if (Build.VERSION.SDK_INT >= 29) bmp = contentResolver.loadThumbnail(uri, Size(px, px), null)
        } catch (e: Exception) { }
        if (bmp == null) {
            try {
                val r = MediaMetadataRetriever()
                r.setDataSource(this, uri)
                if (id >= VOFF) {
                    val f = r.getFrameAtTime(1000000)
                    r.release()
                    if (f != null) {
                        bmp = if (f.width > px)
                            Bitmap.createScaledBitmap(f, px, f.height * px / f.width, true)
                        else f
                    }
                } else {
                    val pic = r.embeddedPicture
                    r.release()
                    if (pic != null) {
                        val o = BitmapFactory.Options()
                        o.inJustDecodeBounds = true
                        BitmapFactory.decodeByteArray(pic, 0, pic.size, o)
                        var s = 1
                        while (o.outWidth / (s * 2) >= px) s *= 2
                        val o2 = BitmapFactory.Options()
                        o2.inSampleSize = s
                        bmp = BitmapFactory.decodeByteArray(pic, 0, pic.size, o2)
                    }
                }
            } catch (e: Exception) { }
        }
        if (bmp == null) return null
        val bo = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 85, bo)
        return bo.toByteArray()
    }

    private fun viewIntent(id: Long): Intent {
        val uri = Uri.parse("content://media/external/audio/media/$id")
        return Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "audio/*")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    private fun incomingUri(i: Intent?): String? =
        if (i?.action == Intent.ACTION_VIEW) i.data?.toString() else null

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 4711 || requestCode == 4712) {
            val r = pendingDelete
            pendingDelete = null
            if (r != null) {
                if (requestCode == 4711) {
                    r.success(resultCode == RESULT_OK)
                } else if (resultCode == RESULT_OK) {
                    try { r.success(contentResolver.delete(pendingUri!!, null, null) > 0) }
                    catch (e: Exception) { r.success(false) }
                } else r.success(false)
            }
            return
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        incomingUri(intent)?.let { channel?.invokeMethod("newIntent", it) }
        intent.getStringExtra("widget_action")?.let {
            intent.removeExtra("widget_action")
            channel?.invokeMethod("widgetAction", it)
        }
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        channel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "music_player/media")
        channel!!.setMethodCallHandler { call, result ->
            when (call.method) {
                "getSongs" -> Thread {
                    val list = ArrayList<Map<String, Any?>>()
                    try {
                        val proj = arrayOf(
                            MediaStore.Audio.Media._ID,
                            MediaStore.Audio.Media.TITLE,
                            MediaStore.Audio.Media.ARTIST,
                            MediaStore.Audio.Media.ALBUM,
                            MediaStore.Audio.Media.DURATION
                        )
                        val c = contentResolver.query(
                            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj,
                            MediaStore.Audio.Media.DURATION + " >= 5000", null,
                            MediaStore.Audio.Media.DATE_ADDED + " DESC"
                        )
                        c?.use {
                            while (it.moveToNext()) {
                                list.add(mapOf(
                                    "id" to it.getLong(0),
                                    "title" to it.getString(1),
                                    "artist" to it.getString(2),
                                    "album" to it.getString(3),
                                    "duration" to it.getLong(4)
                                ))
                            }
                        }
                    } catch (e: Exception) { }
                    runOnUiThread { result.success(list) }
                }.start()
                "getVideos" -> Thread {
                    val list = ArrayList<Map<String, Any?>>()
                    try {
                        val proj = arrayOf(
                            MediaStore.Video.Media._ID,
                            MediaStore.Video.Media.TITLE,
                            MediaStore.Video.Media.BUCKET_DISPLAY_NAME,
                            MediaStore.Video.Media.DURATION
                        )
                        val c = contentResolver.query(
                            MediaStore.Video.Media.EXTERNAL_CONTENT_URI, proj,
                            MediaStore.Video.Media.DURATION + " >= 1000", null,
                            MediaStore.Video.Media.DATE_ADDED + " DESC"
                        )
                        c?.use {
                            while (it.moveToNext()) {
                                list.add(mapOf(
                                    "id" to (it.getLong(0) + VOFF),
                                    "title" to it.getString(1),
                                    "artist" to "Video",
                                    "album" to it.getString(2),
                                    "duration" to it.getLong(3)
                                ))
                            }
                        }
                    } catch (e: Exception) { }
                    runOnUiThread { result.success(list) }
                }.start()
                "getIntentUri" -> result.success(incomingUri(intent))
                "getArt", "getArtBig" -> {
                    val id = (call.arguments as? Number)?.toLong() ?: 0L
                    val px = if (call.method == "getArtBig") 1024 else 256
                    pool.execute {
                        val b = try { loadArt(id, px) } catch (e: Exception) { null }
                        runOnUiThread { result.success(b) }
                    }
                }
                "deleteSong" -> {
                    val id = (call.arguments as? Number)?.toLong() ?: 0L
                    val uri = uriFor(id)
                    try {
                        if (Build.VERSION.SDK_INT >= 30) {
                            val pi = MediaStore.createDeleteRequest(contentResolver, listOf(uri))
                            pendingDelete = result
                            startIntentSenderForResult(pi.intentSender, 4711, null, 0, 0, 0)
                        } else {
                            try {
                                result.success(contentResolver.delete(uri, null, null) > 0)
                            } catch (e: SecurityException) {
                                if (Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException) {
                                    pendingDelete = result
                                    pendingUri = uri
                                    startIntentSenderForResult(e.userAction.actionIntent.intentSender, 4712, null, 0, 0, 0)
                                } else result.success(false)
                            }
                        }
                    } catch (e: Exception) {
                        val r = pendingDelete
                        pendingDelete = null
                        (r ?: result).success(false)
                    }
                }
                "shareSong" -> {
                    val id = (call.arguments as? Number)?.toLong() ?: 0L
                    try {
                        val i = Intent(Intent.ACTION_SEND)
                        i.type = if (id >= VOFF) "video/*" else "audio/*"
                        i.putExtra(Intent.EXTRA_STREAM, uriFor(id))
                        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        startActivity(Intent.createChooser(i, "Share"))
                        result.success(true)
                    } catch (e: Exception) { result.success(false) }
                }
                "getWidgetAction" -> {
                    val a = intent?.getStringExtra("widget_action")
                    intent?.removeExtra("widget_action")
                    result.success(a)
                }
                "updateWidget" -> {
                    val m = call.arguments as? Map<*, *>
                    if (m != null) {
                        getSharedPreferences("widget", MODE_PRIVATE).edit()
                            .putString("title", m["title"] as? String)
                            .putString("artist", m["artist"] as? String)
                            .putBoolean("playing", (m["playing"] as? Boolean) ?: false)
                            .putString("art", m["art"] as? String)
                            .apply()
                        W.refreshAll(this)
                    }
                    result.success(null)
                }
                "pinWidget" -> {
                    val k = (call.arguments as? Number)?.toInt() ?: 0
                    val cls = when (k) {
                        0 -> SearchWidget::class.java
                        1 -> RecoWidget::class.java
                        2 -> CapsuleWidget::class.java
                        else -> PlayerWidget::class.java
                    }
                    val m = AppWidgetManager.getInstance(this)
                    if (Build.VERSION.SDK_INT >= 26 && m.isRequestPinAppWidgetSupported) {
                        try {
                            m.requestPinAppWidget(ComponentName(this, cls), null, null)
                            result.success(true)
                        } catch (e: Exception) { result.success(false) }
                    } else result.success(false)
                }
                "openUrl" -> {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(call.arguments as String)))
                        result.success(true)
                    } catch (e: Exception) { result.success(false) }
                }
                "isDefault" -> {
                    val id = (call.arguments as? Number)?.toLong() ?: 0L
                    val ri = packageManager.resolveActivity(viewIntent(id), PackageManager.MATCH_DEFAULT_ONLY)
                    result.success(ri?.activityInfo?.packageName == packageName)
                }
                "openPicker" -> {
                    val id = (call.arguments as? Number)?.toLong() ?: 0L
                    try { startActivity(viewIntent(id)) } catch (e: Exception) { }
                    result.success(null)
                }
                else -> result.notImplemented()
            }
        }
    }
}
