package com.example.music_player

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.view.KeyEvent
import android.widget.RemoteViews

object W {
    fun prefs(c: Context) = c.getSharedPreferences("widget", Context.MODE_PRIVATE)

    fun open(c: Context, action: String, req: Int): PendingIntent {
        val i = Intent(c, MainActivity::class.java)
        i.action = "com.example.music_player.OPEN"
        i.putExtra("widget_action", action)
        i.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        return PendingIntent.getActivity(c, req, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun key(c: Context, code: Int, req: Int): PendingIntent {
        val i = Intent(Intent.ACTION_MEDIA_BUTTON)
        i.setClassName(c, "com.ryanheise.audioservice.MediaButtonReceiver")
        i.putExtra(Intent.EXTRA_KEY_EVENT, KeyEvent(KeyEvent.ACTION_DOWN, code))
        return PendingIntent.getBroadcast(c, req, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun cover(c: Context, circle: Boolean): Bitmap? {
        val path = prefs(c).getString("art", "") ?: ""
        if (path.isEmpty()) return null
        return try {
            val o = BitmapFactory.Options()
            o.inSampleSize = 4
            val src = BitmapFactory.decodeFile(path, o) ?: return null
            val s = minOf(src.width, src.height)
            val sq = Bitmap.createBitmap(src, (src.width - s) / 2, (src.height - s) / 2, s, s)
            val out = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
            val cv = Canvas(out)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            val r = if (circle) s / 2f else s * 0.2f
            cv.drawRoundRect(RectF(0f, 0f, s.toFloat(), s.toFloat()), r, r, p)
            p.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
            cv.drawBitmap(sq, 0f, 0f, p)
            out
        } catch (e: Exception) { null }
    }

    fun fill(c: Context, rv: RemoteViews, circle: Boolean = false) {
        val p = prefs(c)
        val playing = p.getBoolean("playing", false)
        rv.setTextViewText(R.id.w_title, p.getString("title", null) ?: "Music")
        rv.setTextViewText(R.id.w_artist, p.getString("artist", null) ?: "Turn on the music")
        val bmp = cover(c, circle)
        if (bmp != null) rv.setImageViewBitmap(R.id.w_cover, bmp)
        else rv.setImageViewResource(R.id.w_cover, R.mipmap.ic_launcher)
        rv.setImageViewResource(R.id.w_play, if (playing) R.drawable.ic_pause else R.drawable.ic_play)
        rv.setOnClickPendingIntent(R.id.w_play,
            key(c, if (playing) KeyEvent.KEYCODE_MEDIA_PAUSE else KeyEvent.KEYCODE_MEDIA_PLAY, 1))
        rv.setOnClickPendingIntent(R.id.w_next, key(c, KeyEvent.KEYCODE_MEDIA_NEXT, 2))
        rv.setOnClickPendingIntent(R.id.w_prev, key(c, KeyEvent.KEYCODE_MEDIA_PREVIOUS, 3))
        rv.setOnClickPendingIntent(R.id.w_cover, open(c, "none", 4))
        rv.setOnClickPendingIntent(R.id.w_title, open(c, "none", 5))
    }

    fun search(c: Context): RemoteViews {
        val rv = RemoteViews(c.packageName, R.layout.widget_search)
        fill(c, rv)
        rv.setOnClickPendingIntent(R.id.w_search, open(c, "search", 10))
        return rv
    }

    fun reco(c: Context): RemoteViews {
        val rv = RemoteViews(c.packageName, R.layout.widget_reco)
        rv.setOnClickPendingIntent(R.id.w_root, open(c, "recommend", 11))
        return rv
    }

    fun capsule(c: Context): RemoteViews {
        val rv = RemoteViews(c.packageName, R.layout.widget_capsule)
        fill(c, rv, true)
        return rv
    }

    fun player(c: Context): RemoteViews {
        val rv = RemoteViews(c.packageName, R.layout.widget_player)
        fill(c, rv)
        rv.setOnClickPendingIntent(R.id.w_t_songs, open(c, "songs", 20))
        rv.setOnClickPendingIntent(R.id.w_t_videos, open(c, "videos", 21))
        rv.setOnClickPendingIntent(R.id.w_t_recent, open(c, "recent", 22))
        rv.setOnClickPendingIntent(R.id.w_t_fav, open(c, "fav", 23))
        return rv
    }

    private fun upd(c: Context, cls: Class<*>, build: () -> RemoteViews) {
        val m = AppWidgetManager.getInstance(c)
        val ids = m.getAppWidgetIds(ComponentName(c, cls))
        if (ids.isNotEmpty()) m.updateAppWidget(ids, build())
    }

    fun refreshAll(c: Context) {
        try {
            upd(c, SearchWidget::class.java) { search(c) }
            upd(c, RecoWidget::class.java) { reco(c) }
            upd(c, CapsuleWidget::class.java) { capsule(c) }
            upd(c, PlayerWidget::class.java) { player(c) }
        } catch (e: Exception) { }
    }
}

class SearchWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) { m.updateAppWidget(ids, W.search(c)) }
}
class RecoWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) { m.updateAppWidget(ids, W.reco(c)) }
}
class CapsuleWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) { m.updateAppWidget(ids, W.capsule(c)) }
}
class PlayerWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) { m.updateAppWidget(ids, W.player(c)) }
}
