import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:audio_service/audio_service.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:just_audio/just_audio.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

final audioPlayer = AudioPlayer();
late final MusicHandler handler;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  handler = await AudioService.init(
    builder: () => MusicHandler(audioPlayer),
    config: const AudioServiceConfig(
      androidNotificationChannelId: 'com.example.music_player.audio',
      androidNotificationChannelName: 'Music playback',
      androidNotificationOngoing: true,
      androidNotificationIcon: 'drawable/ic_notif',
    ),
  );
  runApp(const MusicApp());
}

class MusicHandler extends BaseAudioHandler with SeekHandler {
  final AudioPlayer p;
  VoidCallback? onNext, onPrev;
  MusicHandler(this.p) {
    p.playbackEventStream.listen((_) => _push());
    p.playerStateStream.listen((_) => _push());
    p.durationStream.listen((d) {
      final m = mediaItem.value;
      if (m != null && d != null) mediaItem.add(m.copyWith(duration: d));
    });
  }

  void _push() {
    playbackState.add(PlaybackState(
      controls: [
        MediaControl.skipToPrevious,
        p.playing ? MediaControl.pause : MediaControl.play,
        MediaControl.skipToNext,
      ],
      systemActions: const {MediaAction.seek},
      androidCompactActionIndices: const [0, 1, 2],
      processingState: const {
        ProcessingState.idle: AudioProcessingState.idle,
        ProcessingState.loading: AudioProcessingState.loading,
        ProcessingState.buffering: AudioProcessingState.buffering,
        ProcessingState.ready: AudioProcessingState.ready,
        ProcessingState.completed: AudioProcessingState.completed,
      }[p.processingState]!,
      playing: p.playing,
      updatePosition: p.position,
      bufferedPosition: p.bufferedPosition,
      speed: p.speed,
    ));
  }

  @override
  Future<void> play() => p.play();
  @override
  Future<void> pause() => p.pause();
  @override
  Future<void> seek(Duration position) => p.seek(position);
  @override
  Future<void> skipToNext() async => onNext?.call();
  @override
  Future<void> skipToPrevious() async => onPrev?.call();
  @override
  Future<void> stop() async {
    await p.stop();
    await super.stop();
  }
}

Future<Uri?> artUri(Song s) async {
  if (s.id < 0) return null;
  try {
    final b = await bigCache.putIfAbsent(
        s.id, () => mediaCh.invokeMethod<Uint8List>('getArtBig', s.id));
    if (b == null) return null;
    final f = File('${Directory.systemTemp.path}/art_${s.id}.jpg');
    if (!await f.exists()) await f.writeAsBytes(b);
    return Uri.file(f.path);
  } catch (_) {
    return null;
  }
}

const mediaCh = MethodChannel('music_player/media');
const kVideoOff = 4000000000000;
final artCache = <int, Future<Uint8List?>>{};
final bigCache = <int, Future<Uint8List?>>{};

class Art extends StatelessWidget {
  final Song s;
  final double size, radius;
  final bool circle, big;
  const Art(this.s, this.size,
      {this.circle = false, this.big = false, this.radius = 7, super.key});

  Widget fallback() => Container(
        width: size,
        height: size,
        color: s.color,
        child: Icon(s.video ? Icons.movie : Icons.music_note,
            color: Colors.white70, size: size * .45),
      );

  @override
  Widget build(BuildContext context) {
    final cache = big ? bigCache : artCache;
    final f = s.id < 0
        ? Future<Uint8List?>.value(null)
        : cache.putIfAbsent(s.id,
            () => mediaCh.invokeMethod<Uint8List>(big ? 'getArtBig' : 'getArt', s.id));
    final w = FutureBuilder<Uint8List?>(
      future: f,
      builder: (_, snap) {
        final d = snap.data;
        if (d == null) return fallback();
        return Image.memory(d,
            width: size,
            height: size,
            fit: BoxFit.cover,
            cacheWidth: big ? 1024 : 256,
            gaplessPlayback: true,
            errorBuilder: (_, __, ___) => fallback());
      },
    );
    return SizedBox(
      width: size,
      height: size,
      child: circle
          ? ClipOval(child: w)
          : ClipRRect(borderRadius: BorderRadius.circular(radius), child: w),
    );
  }
}

class MusicApp extends StatelessWidget {
  const MusicApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Music player',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorSchemeSeed: const Color(0xFF7C5CD6),
          scaffoldBackgroundColor: Colors.white,
        ),
        home: const Home(),
      );
}

class Song {
  final int id;
  final String title, artist, album;
  final String? uri;
  Song(this.id, this.title, this.artist, this.album, [this.uri]);
  bool get video => id >= kVideoOff;
  factory Song.from(Map m) {
    String clean(dynamic v, String d) {
      final s = (v ?? '').toString();
      return (s.isEmpty || s == '<unknown>') ? d : s;
    }
    final id = m['id'] as int;
    return Song(
        id,
        clean(m['title'], 'Unknown title'),
        clean(m['artist'], 'Unknown artist'),
        clean(m['album'], 'Unknown album'),
        id >= kVideoOff
            ? 'content://media/external/video/media/${id - kVideoOff}'
            : null);
  }
  Color get color =>
      HSLColor.fromAHSL(1, (id * 47 % 360).toDouble(), .35, .42).toColor();
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  static const ch = MethodChannel('music_player/media');
  final player = audioPlayer;
  final rnd = Random();
  List<Song> all = [];
  List<Song> videos = [];
  String q = '';
  int tab = 0;
  bool asc = true, shuffle = false, loading = true, denied = false;
  Song? cur;
  final scaffoldKey = GlobalKey<ScaffoldState>();
  final searchFocus = FocusNode();
  String artPath = '';
  final List<Song> queue = [];
  Map<String, List<int>> playlists = {};
  List<int> recent = [];
  String? view;
  final curN = ValueNotifier<Song?>(null);
  final repeatN = ValueNotifier<bool>(false);
  final favs = ValueNotifier<Set<int>>(<int>{});

  @override
  void initState() {
    super.initState();
    player.processingStateStream.listen((s) {
      if (s == ProcessingState.completed) next();
    });
    player.playerStateStream.listen((_) {
      if (mounted) setState(() {});
      pushWidget();
    });
    handler.onNext = next;
    handler.onPrev = prev;
    SharedPreferences.getInstance().then((p) {
      favs.value = (p.getStringList('favs') ?? []).map(int.parse).toSet();
      recent = (p.getStringList('recent') ?? []).map(int.parse).toList();
      try {
        final m = jsonDecode(p.getString('playlists') ?? '{}') as Map;
        playlists = m.map((k, v) =>
            MapEntry(k as String, (v as List).map((e) => e as int).toList()));
      } catch (_) {}
      if (mounted) setState(() {});
    });
    ch.setMethodCallHandler((c) async {
      if (c.method == 'newIntent') openUri(c.arguments as String?);
      if (c.method == 'widgetAction') doWidgetAction(c.arguments as String?);
    });
    load();
  }

  void openUri(String? u) {
    if (u == null) return;
    final seg = Uri.parse(u).pathSegments;
    final last = seg.isEmpty ? 'Audio' : seg.last;
    final id = int.tryParse(last);
    for (final s in all) {
      if (s.id == id) {
        play(s);
        return;
      }
    }
    play(Song(-1, Uri.decodeComponent(last), 'Unknown artist', 'Unknown album', u));
  }

  Future<void> promptDefault() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      if (prefs.getBool('skipDefault') ?? false) return;
      final sid = all.isNotEmpty ? all.first.id : 0;
      final d = await ch.invokeMethod<bool>('isDefault', sid) ?? true;
      if (d || !mounted) return;
      final go = await showDialog<bool>(
        context: context,
        builder: (c) => AlertDialog(
          title: const Text('Set as default music player'),
          content: const Text(
              'Make Music player your default app for opening audio files? Choose "Music player" and tap "Always".'),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(c, false), child: const Text('Skip')),
            FilledButton(
                onPressed: () => Navigator.pop(c, true),
                child: const Text('Set default')),
          ],
        ),
      );
      if (go == true) {
        await ch.invokeMethod('openPicker', sid);
      } else {
        await prefs.setBool('skipDefault', true);
      }
    } catch (_) {}
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future<void> load() async {
    setState(() {
      loading = true;
      denied = false;
    });
    final r = await [Permission.audio, Permission.videos, Permission.storage, Permission.notification].request();
    if (!(r[Permission.audio]?.isGranted == true || r[Permission.storage]?.isGranted == true)) {
      setState(() {
        loading = false;
        denied = true;
      });
      return;
    }
    try {
      final res = await ch.invokeMethod<List<dynamic>>('getSongs');
      all = (res ?? []).map((e) => Song.from(Map.from(e as Map))).toList();
    } catch (_) {}
    try {
      final vr = await ch.invokeMethod<List<dynamic>>('getVideos');
      videos = (vr ?? []).map((e) => Song.from(Map.from(e as Map))).toList();
    } catch (_) {}
    if (mounted) setState(() => loading = false);
    try {
      final u = await ch.invokeMethod<String>('getIntentUri');
      openUri(u);
    } catch (_) {}
    try {
      doWidgetAction(await ch.invokeMethod<String>('getWidgetAction'));
    } catch (_) {}
    if (mounted) await promptDefault();
  }

  List<Song> get shown {
    var l = (view == null ? all : [...all, ...videos])
        .where((s) => ('${s.title} ${s.artist} ${s.album}')
            .toLowerCase()
            .contains(q.toLowerCase()))
        .toList();
    if (view == 'recent') {
      l = l.where((s) => recent.contains(s.id)).toList();
      l.sort((a, b) => recent.indexOf(a.id).compareTo(recent.indexOf(b.id)));
      return l;
    }
    if (view == 'fav') {
      l = l.where((s) => favs.value.contains(s.id)).toList();
    } else if (view != null && view!.startsWith('pl:')) {
      final ids = playlists[view!.substring(3)] ?? <int>[];
      l = l.where((s) => ids.contains(s.id)).toList();
    }
    l.sort((a, b) => asc
        ? a.title.toLowerCase().compareTo(b.title.toLowerCase())
        : b.title.toLowerCase().compareTo(a.title.toLowerCase()));
    return l;
  }

  List<Song> get shownVideos {
    final l = videos
        .where((s) => ('${s.title} ${s.album}').toLowerCase().contains(q.toLowerCase()))
        .toList();
    l.sort((a, b) => asc
        ? a.title.toLowerCase().compareTo(b.title.toLowerCase())
        : b.title.toLowerCase().compareTo(a.title.toLowerCase()));
    return l;
  }

  List<Song> get ctx => (cur?.video ?? false) ? shownVideos : shown;

  Future<void> play(Song s) async {
    setState(() => cur = s);
    curN.value = s;
    if (s.id >= 0) {
      recent.remove(s.id);
      recent.insert(0, s.id);
      if (recent.length > 30) recent.removeRange(30, recent.length);
      savePl();
    }
    final art = await artUri(s);
    artPath = art?.toFilePath() ?? '';
    handler.mediaItem.add(MediaItem(
        id: '${s.id}', title: s.title, artist: s.artist, album: s.album, artUri: art));
    try {
      await player.setAudioSource(AudioSource.uri(
          Uri.parse(s.uri ?? 'content://media/external/audio/media/${s.id}')));
      player.play();
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Cannot play this file')));
      }
    }
  }

  void next() {
    if (queue.isNotEmpty) {
      play(queue.removeAt(0));
      return;
    }
    final l = ctx;
    if (l.isEmpty) return;
    final i = cur == null ? -1 : l.indexWhere((s) => s.id == cur!.id);
    play(shuffle ? l[rnd.nextInt(l.length)] : l[(i + 1) % l.length]);
  }

  void prev() {
    final l = ctx;
    if (l.isEmpty) return;
    if (player.position.inSeconds > 3) {
      player.seek(Duration.zero);
      return;
    }
    final i = cur == null ? 0 : l.indexWhere((s) => s.id == cur!.id);
    play(l[(i <= 0 ? l.length : i) - 1]);
  }

  void toggleRepeat() {
    repeatN.value = !repeatN.value;
    player.setLoopMode(repeatN.value ? LoopMode.one : LoopMode.off);
  }

  Future<void> toggleFav(int id) async {
    final n = Set<int>.from(favs.value);
    n.contains(id) ? n.remove(id) : n.add(id);
    favs.value = n;
    final p = await SharedPreferences.getInstance();
    await p.setStringList('favs', n.map((e) => '$e').toList());
  }

  Future<void> savePl() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('playlists', jsonEncode(playlists));
    await p.setStringList('recent', recent.map((e) => '$e').toList());
  }

  void toast(String m) {
    if (!mounted) return;
    final sm = ScaffoldMessenger.of(context);
    sm.hideCurrentSnackBar();
    sm.showSnackBar(SnackBar(content: Text(m), duration: const Duration(seconds: 2)));
  }

  static const _sheetShape = RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(36)));

  void songMenu(Song s) {
    Widget item(BuildContext c, String t, VoidCallback f) => InkWell(
          onTap: () {
            Navigator.pop(c);
            f();
          },
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 6),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(t,
                  style: const TextStyle(
                      fontSize: 20, fontWeight: FontWeight.w700, color: Colors.black)),
            ),
          ),
        );
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: _sheetShape,
      builder: (c) => SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, 28, 24, 12),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text(s.title,
                  textAlign: TextAlign.center,
                  maxLines: 4,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      fontSize: 22, fontWeight: FontWeight.w700, color: Colors.black)),
              const SizedBox(height: 18),
              item(c, 'Play later', () {
                queue.insert(0, s);
                toast('Will play next');
              }),
              item(c, 'Add to queue', () {
                queue.add(s);
                toast('Added to queue');
              }),
              item(c, 'Add to playlist', () => addToPlaylist(s)),
              item(c, 'Delete', () => confirmDelete(s)),
              item(c, 'Share', () => share(s)),
            ]),
          ),
        ),
      ),
    );
  }

  Future<String?> askName() {
    final c = TextEditingController();
    return showDialog<String>(
      context: context,
      builder: (d) => AlertDialog(
        title: const Text('New playlist'),
        content: TextField(
            controller: c,
            autofocus: true,
            decoration: const InputDecoration(hintText: 'Playlist name')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d), child: const Text('Cancel')),
          FilledButton(
              onPressed: () => Navigator.pop(d, c.text.trim()),
              child: const Text('Create')),
        ],
      ),
    );
  }

  void addTo(String name, Song s) {
    final l = playlists.putIfAbsent(name, () => <int>[]);
    if (!l.contains(s.id)) l.add(s.id);
    savePl();
    setState(() {});
    toast('Added to $name');
  }

  void addToPlaylist(Song s) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: _sheetShape,
      builder: (bc) => SafeArea(
        child: ListView(shrinkWrap: true, padding: const EdgeInsets.all(12), children: [
          const Padding(
            padding: EdgeInsets.all(14),
            child: Text('Add to playlist',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
          ),
          ListTile(
            leading: const Icon(Icons.add),
            title: const Text('New playlist'),
            onTap: () async {
              Navigator.pop(bc);
              final n = await askName();
              if (n != null && n.isNotEmpty) addTo(n, s);
            },
          ),
          for (final e in playlists.entries.toList())
            ListTile(
              leading: const Icon(Icons.queue_music),
              title: Text(e.key),
              subtitle: Text('${e.value.length} songs'),
              onTap: () {
                Navigator.pop(bc);
                addTo(e.key, s);
              },
            ),
        ]),
      ),
    );
  }

  void showPlaylists() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: _sheetShape,
      builder: (bc) => StatefulBuilder(
        builder: (bc, set) => SafeArea(
          child: ListView(shrinkWrap: true, padding: const EdgeInsets.all(12), children: [
            const Padding(
              padding: EdgeInsets.all(14),
              child: Text('Playlists',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
            ),
            ListTile(
              leading: const Icon(Icons.add),
              title: const Text('New playlist'),
              onTap: () async {
                Navigator.pop(bc);
                final n = await askName();
                if (n != null && n.isNotEmpty) {
                  playlists.putIfAbsent(n, () => <int>[]);
                  savePl();
                }
                showPlaylists();
              },
            ),
            if (playlists.isEmpty)
              const Padding(
                  padding: EdgeInsets.all(20),
                  child: Center(child: Text('No playlists yet'))),
            for (final e in playlists.entries.toList())
              ListTile(
                leading: const Icon(Icons.queue_music),
                title: Text(e.key),
                subtitle: Text('${e.value.length} songs'),
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () {
                    playlists.remove(e.key);
                    if (view == 'pl:${e.key}') view = null;
                    savePl();
                    set(() {});
                    setState(() {});
                  },
                ),
                onTap: () {
                  Navigator.pop(bc);
                  setState(() {
                    view = 'pl:${e.key}';
                    tab = 0;
                  });
                },
              ),
          ]),
        ),
      ),
    );
  }

  Future<void> share(Song s) async {
    try {
      final ok = await ch.invokeMethod<bool>('shareSong', s.id) ?? false;
      if (!ok) toast('Cannot share this file');
    } catch (_) {
      toast('Cannot share this file');
    }
  }

  Future<void> confirmDelete(Song s) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: const Text('Delete song?'),
        content: Text('"${s.title}" will be deleted from your phone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('Delete')),
        ],
      ),
    );
    if (ok != true) return;
    var done = false;
    try {
      done = await ch.invokeMethod<bool>('deleteSong', s.id) ?? false;
    } catch (_) {}
    if (!done) {
      toast('Could not delete this song');
      return;
    }
    final wasCur = cur?.id == s.id;
    if (wasCur) {
      await player.stop();
      await handler.stop();
    }
    setState(() {
      all.removeWhere((x) => x.id == s.id);
      videos.removeWhere((x) => x.id == s.id);
      queue.removeWhere((x) => x.id == s.id);
      for (final v in playlists.values) {
        v.remove(s.id);
      }
      recent.remove(s.id);
      if (wasCur) cur = null;
    });
    if (wasCur) curN.value = null;
    favs.value = Set<int>.from(favs.value)..remove(s.id);
    savePl();
    toast('Deleted');
    if (wasCur && mounted) Navigator.of(context).popUntil((r) => r.isFirst);
  }

  void pushWidget() {
    final s = cur;
    if (s == null) return;
    ch.invokeMethod('updateWidget', {
      'title': s.title,
      'artist': s.artist,
      'playing': player.playing,
      'art': artPath,
    }).catchError((_) {});
  }

  void doWidgetAction(String? a) {
    if (a == null || a == 'none') return;
    switch (a) {
      case 'search':
        setState(() {
          tab = 0;
          view = null;
        });
        WidgetsBinding.instance.addPostFrameCallback((_) => searchFocus.requestFocus());
        break;
      case 'recommend':
        if (all.isNotEmpty) {
          shuffle = true;
          play(all[rnd.nextInt(all.length)]);
        }
        break;
      case 'songs':
        setState(() {
          tab = 0;
          view = null;
        });
        break;
      case 'videos':
        setState(() {
          tab = 1;
          view = null;
        });
        break;
      case 'recent':
        setState(() {
          tab = 0;
          view = 'recent';
        });
        break;
      case 'fav':
        setState(() {
          tab = 0;
          view = 'fav';
        });
        break;
    }
  }

  Future<void> pinWidget(int k) async {
    var ok = false;
    try {
      ok = await ch.invokeMethod<bool>('pinWidget', k) ?? false;
    } catch (_) {}
    if (!ok) {
      toast('Long-press the home screen, open Widgets and choose Music player');
    }
  }

  Future<void> openTelegram() async {
    var ok = false;
    try {
      ok = await ch.invokeMethod<bool>('openUrl', 'https://t.me/Bd_24xtechHub') ?? false;
    } catch (_) {}
    if (!ok) toast('Cannot open Telegram');
  }

  Widget drawerItem(Widget icon, String t, VoidCallback f) => InkWell(
        onTap: f,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 8),
          child: Row(children: [
            SizedBox(width: 34, child: Center(child: icon)),
            const SizedBox(width: 20),
            Expanded(child: Text(t, style: const TextStyle(fontSize: 21, color: Colors.black))),
          ]),
        ),
      );

  Widget drawer() => Drawer(
        width: MediaQuery.of(context).size.width * .83,
        backgroundColor: Colors.white,
        shape: const RoundedRectangleBorder(),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 20, 16, 0),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              drawerItem(const Icon(Icons.widgets_outlined, size: 30, color: Colors.black87),
                  'Home screen widget', () {
                Navigator.pop(context);
                Navigator.of(context)
                    .push(MaterialPageRoute(builder: (_) => WidgetsPage(this)));
              }),
              const Padding(
                  padding: EdgeInsets.symmetric(vertical: 14), child: Divider(height: 1)),
              const Padding(
                padding: EdgeInsets.fromLTRB(8, 12, 8, 4),
                child: Text('Support & Contact',
                    style: TextStyle(
                        fontSize: 16, color: Colors.black45, fontWeight: FontWeight.w600)),
              ),
              drawerItem(const TelegramLogo(32), 'Contact', () {
                Navigator.pop(context);
                openTelegram();
              }),
            ]),
          ),
        ),
      );

  void openNow() {
    Navigator.of(context).push(PageRouteBuilder(
      transitionDuration: const Duration(milliseconds: 300),
      pageBuilder: (_, a, __) => SlideTransition(
        position: Tween(begin: const Offset(0, 1), end: Offset.zero)
            .animate(CurvedAnimation(parent: a, curve: Curves.easeOutCubic)),
        child: NowPlaying(this),
      ),
    ));
  }

  void toggle() {
    player.playing ? player.pause() : player.play();
  }

  Widget tile(String t, IconData ic, List<Color> c, VoidCallback f) => Expanded(
        child: GestureDetector(
          onTap: f,
          child: Container(
          height: 86,
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            gradient: LinearGradient(
                colors: c, begin: Alignment.topLeft, end: Alignment.bottomRight),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Icon(ic, color: Colors.white, size: 28),
              Text(t,
                  style: const TextStyle(
                      color: Colors.white, fontSize: 15, fontWeight: FontWeight.w500)),
            ],
          ),
        )),
      );

  Widget promo(String t, Color c, {bool round = false}) => Expanded(
        child: Column(children: [
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
                color: c,
                borderRadius: BorderRadius.circular(round ? 25 : 13)),
          ),
          const SizedBox(height: 5),
          Text(t, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 12)),
        ]),
      );

  Widget header() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          IconButton(
              onPressed: () => scaffoldKey.currentState?.openDrawer(),
              icon: const Icon(Icons.tune_rounded, size: 30)),
          const SizedBox(width: 4),
          Expanded(
            child: TextField(
              focusNode: searchFocus,
              onChanged: (v) => setState(() => q = v),
              decoration: InputDecoration(
                hintText: 'Search songs, playlists, and artists',
                hintStyle: const TextStyle(color: Colors.black45, fontSize: 15),
                prefixIcon: const Icon(Icons.search, color: Colors.black45),
                suffixIcon: const Icon(Icons.mic_none, color: Colors.black54),
                filled: true,
                fillColor: const Color(0xFFF1F1F4),
                contentPadding: EdgeInsets.zero,
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30),
                    borderSide: BorderSide.none),
              ),
            ),
          ),
        ]),
        const SizedBox(height: 18),
        Row(children: [
          tile('Favorites', Icons.favorite, const [Color(0xFF6E2A43), Color(0xFFB0476A)],
              () => setState(() {
                    view = 'fav';
                    tab = 0;
                  })),
          const SizedBox(width: 12),
          tile('Playlists', Icons.album, const [Color(0xFF1C3347), Color(0xFF4D7F94)], showPlaylists),
          const SizedBox(width: 12),
          tile('Recent', Icons.schedule, const [Color(0xFF2A2457), Color(0xFF5A4CA8)],
              () => setState(() {
                    view = 'recent';
                    tab = 0;
                  })),
        ]),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.fromLTRB(12, 14, 12, 12),
          decoration: BoxDecoration(
              color: const Color(0xFFF0E9FB), borderRadius: BorderRadius.circular(20)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Padding(
              padding: EdgeInsets.only(left: 4, bottom: 12),
              child: Text('Promotion',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w500)),
            ),
            Row(children: [
              promo('Bitunix Pro: B…', const Color(0xFFB6F23A)),
              promo('Music for Mo…', const Color(0xFFFDC82B), round: true),
              promo('Color Block: …', const Color(0xFF3B7A3B)),
              promo('Eyecon Caller…', const Color(0xFF1565E8)),
            ]),
          ]),
        ),
        const SizedBox(height: 18),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          for (final e in ['Songs', 'Videos', 'Artists', 'Albums'].asMap().entries)
            GestureDetector(
              onTap: () => setState(() => tab = e.key),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                decoration: BoxDecoration(
                    color: tab == e.key ? Colors.black : Colors.transparent,
                    borderRadius: BorderRadius.circular(22)),
                child: Text(e.value,
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: tab == e.key ? FontWeight.w500 : FontWeight.w400,
                        color: tab == e.key ? Colors.white : Colors.black54)),
              ),
            ),
        ]),
        const SizedBox(height: 12),
        if (view != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Align(
              alignment: Alignment.centerLeft,
              child: InputChip(
                label: Text(view == 'fav'
                    ? 'Favorites'
                    : view == 'recent'
                        ? 'Recent'
                        : view!.substring(3)),
                onDeleted: () => setState(() => view = null),
              ),
            ),
          ),
        if (tab == 0 || tab == 1)
          Row(children: [
            GestureDetector(
              onTap: () {
                final l = tab == 1 ? shownVideos : shown;
                if (l.isNotEmpty) {
                  shuffle = true;
                  play(l[rnd.nextInt(l.length)]);
                }
              },
              child: const CircleAvatar(
                  radius: 23,
                  backgroundColor: Colors.black,
                  child: Icon(Icons.play_arrow_rounded, color: Colors.white, size: 30)),
            ),
            const SizedBox(width: 12),
            const Expanded(
                child: Text('Shuffle playback',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500))),
            IconButton(
                onPressed: () => setState(() => asc = !asc),
                icon: const Icon(Icons.swap_vert_rounded, size: 30)),
            IconButton(onPressed: () {}, icon: const Icon(Icons.playlist_add_check, size: 30)),
          ]),
      ]);

  Widget songRow(Song s) {
    final on = cur?.id == s.id;
    return InkWell(
      onTap: () {
        shuffle = false;
        play(s);
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 9),
        child: Row(children: [
          Art(s, 64),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(s.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontSize: 17.5,
                      color: on ? const Color(0xFF7C5CD6) : Colors.black)),
              const SizedBox(height: 5),
              Row(children: [
                const Icon(Icons.smartphone_outlined, size: 18, color: Colors.black38),
                const SizedBox(width: 6),
                Expanded(
                  child: Text('${s.artist} | ${s.album}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 14.5, color: Colors.black45)),
                ),
              ]),
            ]),
          ),
          IconButton(
              onPressed: () => songMenu(s),
              icon: const Icon(Icons.more_vert, color: Colors.black45)),
        ]),
      ),
    );
  }

  Widget groups(bool byArtist) {
    final m = <String, int>{};
    for (final s in all) {
      final k = byArtist ? s.artist : s.album;
      m[k] = (m[k] ?? 0) + 1;
    }
    final keys = m.keys.toList()..sort();
    return Column(children: [
      for (final k in keys)
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: CircleAvatar(
              backgroundColor: const Color(0xFFF0E9FB),
              child: Icon(byArtist ? Icons.person : Icons.album,
                  color: const Color(0xFF7C5CD6))),
          title: Text(k, maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: Text('${m[k]} songs'),
          onTap: () => setState(() {
            q = k;
            tab = 0;
          }),
        ),
    ]);
  }

  Widget body() {
    if (loading) {
      return const Padding(
          padding: EdgeInsets.all(40), child: Center(child: CircularProgressIndicator()));
    }
    if (denied) {
      return Padding(
        padding: const EdgeInsets.all(30),
        child: Column(children: [
          const Text('Allow audio access to see the songs on your phone.',
              textAlign: TextAlign.center),
          const SizedBox(height: 12),
          FilledButton(onPressed: openAppSettings, child: const Text('Open settings')),
          TextButton(onPressed: load, child: const Text('Try again')),
        ]),
      );
    }
    if (tab == 1) {
      final v = shownVideos;
      if (v.isEmpty) {
        return const Padding(
            padding: EdgeInsets.all(40), child: Center(child: Text('No videos')));
      }
      return Column(children: [for (final s in v) songRow(s)]);
    }
    if (tab == 2) return groups(true);
    if (tab == 3) return groups(false);
    final l = shown;
    if (l.isEmpty) {
      return const Padding(
          padding: EdgeInsets.all(40), child: Center(child: Text('No songs found')));
    }
    return Column(children: [for (final s in l) songRow(s)]);
  }

  Widget mini() {
    final s = cur!;
    return GestureDetector(
      onTap: openNow,
      child: Container(
      height: 62,
      decoration: BoxDecoration(
          color: const Color(0xFFD9D2E9), borderRadius: BorderRadius.circular(32)),
      clipBehavior: Clip.antiAlias,
      child: Stack(children: [
        Row(children: [
          const SizedBox(width: 8),
          Art(s, 46, circle: true),
          const SizedBox(width: 12),
          Expanded(
            child: Column(mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(s.title, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
              Text(s.artist, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 13, color: Colors.black54)),
            ]),
          ),
          GestureDetector(
            onTap: toggle,
            child: Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                  shape: BoxShape.circle, border: Border.all(width: 2, color: Colors.black87)),
              child: Icon(player.playing ? Icons.pause : Icons.play_arrow, size: 26),
            ),
          ),
          IconButton(onPressed: next, icon: const Icon(Icons.skip_next, size: 28)),
          const SizedBox(width: 4),
        ]),
        Positioned(
          left: 24,
          right: 24,
          bottom: 0,
          child: StreamBuilder<Duration>(
            stream: player.positionStream,
            builder: (_, snap) {
              final d = player.duration?.inMilliseconds ?? 0;
              final p = snap.data?.inMilliseconds ?? 0;
              return LinearProgressIndicator(
                  value: d > 0 ? (p / d).clamp(0.0, 1.0) : 0,
                  minHeight: 3,
                  color: const Color(0xFF7C5CD6),
                  backgroundColor: Colors.black12);
            },
          ),
        ),
      ]),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      drawer: drawer(),
      body: SafeArea(
        child: Stack(children: [
          ListView(
            padding: EdgeInsets.fromLTRB(16, 12, 16, cur == null ? 24 : 100),
            children: [header(), body()],
          ),
          if (cur != null)
            Positioned(left: 16, right: 16, bottom: 12, child: mini()),
        ]),
      ),
    );
  }
}


class NowPlaying extends StatefulWidget {
  final _HomeState h;
  const NowPlaying(this.h, {super.key});
  @override
  State<NowPlaying> createState() => _NowPlayingState();
}

class _NowPlayingState extends State<NowPlaying> {
  double? drag;

  String fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return d.inHours > 0 ? '${d.inHours}:$m:$s' : '$m:$s';
  }

  void queue() {
    final h = widget.h;
    Widget tile(BuildContext c, Song s, {bool q = false}) => ListTile(
          leading: Art(s, 44),
          title: Text(s.title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                  color: h.cur?.id == s.id ? const Color(0xFFA48BFF) : Colors.white)),
          subtitle: Text(s.artist,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Colors.white54)),
          trailing: q
              ? IconButton(
                  icon: const Icon(Icons.close, color: Colors.white54),
                  onPressed: () {
                    h.queue.remove(s);
                    Navigator.pop(c);
                    queue();
                  })
              : null,
          onTap: () {
            Navigator.pop(c);
            if (q) h.queue.remove(s);
            h.play(s);
          },
        );
    Widget head(String t) => Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 4),
          child: Text(t,
              style: const TextStyle(
                  color: Colors.white70, fontSize: 16, fontWeight: FontWeight.w600)),
        );
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1B1B1F),
      builder: (c) => ListView(children: [
        if (h.queue.isNotEmpty) ...[
          head('Up next'),
          for (final s in h.queue.toList()) tile(c, s, q: true),
          head('All songs'),
        ],
        for (final s in h.ctx) tile(c, s),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final h = widget.h;
    const bg = Color(0xFF0A0A0C);
    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(
        child: ValueListenableBuilder<Song?>(
          valueListenable: h.curN,
          builder: (_, s, __) {
            if (s == null) return const SizedBox();
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 22),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  IconButton(
                      onPressed: () => Navigator.pop(context),
                      padding: EdgeInsets.zero,
                      icon: const Icon(Icons.keyboard_arrow_down,
                          color: Colors.white, size: 38)),
                  const Spacer(),
                  const Icon(Icons.checkroom_outlined, color: Colors.white, size: 30),
                  const SizedBox(width: 22),
                  const Icon(Icons.tune_rounded, color: Colors.white, size: 30),
                  const SizedBox(width: 16),
                  IconButton(
                      onPressed: () => h.songMenu(s),
                      padding: EdgeInsets.zero,
                      icon: const Icon(Icons.more_vert, color: Colors.white, size: 28)),
                ]),
                const SizedBox(height: 12),
                LayoutBuilder(
                    builder: (_, bc) =>
                        Art(s, bc.maxWidth, big: true, radius: 22)),
                const SizedBox(height: 14),
                Row(children: [
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(s.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 30,
                              fontWeight: FontWeight.w700)),
                      const SizedBox(height: 8),
                      Text(s.artist,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: Colors.white60, fontSize: 20)),
                    ]),
                  ),
                  ValueListenableBuilder<Set<int>>(
                    valueListenable: h.favs,
                    builder: (_, f, __) => IconButton(
                      onPressed: () => h.toggleFav(s.id),
                      icon: Icon(f.contains(s.id) ? Icons.star : Icons.star_border,
                          color: f.contains(s.id) ? const Color(0xFFFFC83D) : Colors.white,
                          size: 38),
                    ),
                  ),
                ]),
                const SizedBox(height: 20),
                Row(children: [
                  const Text('No lyrics',
                      style: TextStyle(color: Colors.white54, fontSize: 20)),
                  const SizedBox(width: 12),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 7),
                    decoration: BoxDecoration(
                        color: Colors.white24, borderRadius: BorderRadius.circular(20)),
                    child: const Text('Add',
                        style: TextStyle(
                            color: Colors.white60,
                            fontSize: 18,
                            fontWeight: FontWeight.w600)),
                  ),
                ]),
                const Spacer(),
                StreamBuilder<Duration>(
                  stream: h.player.positionStream,
                  builder: (_, snap) {
                    final dur = h.player.duration ?? Duration.zero;
                    final pos = snap.data ?? Duration.zero;
                    final max = dur.inMilliseconds > 0 ? dur.inMilliseconds.toDouble() : 1.0;
                    final v = drag ?? pos.inMilliseconds.toDouble().clamp(0.0, max);
                    return Column(children: [
                      SliderTheme(
                        data: SliderTheme.of(context).copyWith(
                          trackHeight: 3,
                          thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 7),
                          overlayShape: SliderComponentShape.noOverlay,
                          activeTrackColor: Colors.white,
                          inactiveTrackColor: Colors.white24,
                          thumbColor: Colors.white,
                        ),
                        child: Slider(
                          value: v,
                          max: max,
                          onChanged: (x) => setState(() => drag = x),
                          onChangeEnd: (x) {
                            h.player.seek(Duration(milliseconds: x.toInt()));
                            setState(() => drag = null);
                          },
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                          Text(fmt(Duration(milliseconds: v.toInt())),
                              style: const TextStyle(color: Colors.white54, fontSize: 16)),
                          Text(fmt(dur),
                              style: const TextStyle(color: Colors.white54, fontSize: 16)),
                        ]),
                      ),
                    ]);
                  },
                ),
                const SizedBox(height: 22),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  ValueListenableBuilder<bool>(
                    valueListenable: h.repeatN,
                    builder: (_, on, __) => IconButton(
                      onPressed: h.toggleRepeat,
                      icon: Icon(on ? Icons.repeat_one : Icons.repeat,
                          color: on ? const Color(0xFFA48BFF) : Colors.white, size: 32),
                    ),
                  ),
                  IconButton(
                      onPressed: h.prev,
                      icon: const Icon(Icons.skip_previous, color: Colors.white, size: 42)),
                  StreamBuilder<PlayerState>(
                    stream: h.player.playerStateStream,
                    builder: (_, snap) => GestureDetector(
                      onTap: h.toggle,
                      child: Container(
                        width: 94,
                        height: 94,
                        decoration: const BoxDecoration(
                            shape: BoxShape.circle, color: Color(0xFF3A3A3C)),
                        child: Icon(h.player.playing ? Icons.pause : Icons.play_arrow,
                            color: Colors.white, size: 50),
                      ),
                    ),
                  ),
                  IconButton(
                      onPressed: h.next,
                      icon: const Icon(Icons.skip_next, color: Colors.white, size: 42)),
                  IconButton(
                      onPressed: queue,
                      icon: const Icon(Icons.queue_music, color: Colors.white, size: 32)),
                ]),
                const SizedBox(height: 36),
              ]),
            );
          },
        ),
      ),
    );
  }
}


class TelegramLogo extends StatelessWidget {
  final double size;
  const TelegramLogo(this.size, {super.key});
  @override
  Widget build(BuildContext context) => CustomPaint(size: Size(size, size), painter: _TgPainter());
}

class _TgPainter extends CustomPainter {
  @override
  void paint(Canvas c, Size s) {
    final w = s.width;
    c.drawCircle(Offset(w / 2, w / 2), w / 2, Paint()..color = const Color(0xFF2AABEE));
    Offset o(double x, double y) => Offset(x * w, y * w);
    final p = Path()
      ..moveTo(o(.20, .49).dx, o(.20, .49).dy)
      ..lineTo(o(.78, .26).dx, o(.78, .26).dy)
      ..lineTo(o(.67, .76).dx, o(.67, .76).dy)
      ..lineTo(o(.50, .62).dx, o(.50, .62).dy)
      ..lineTo(o(.41, .71).dx, o(.41, .71).dy)
      ..lineTo(o(.40, .58).dx, o(.40, .58).dy)
      ..lineTo(o(.70, .34).dx, o(.70, .34).dy)
      ..lineTo(o(.35, .54).dx, o(.35, .54).dy)
      ..close();
    c.drawPath(p, Paint()..color = Colors.white);
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}

class WidgetsPage extends StatelessWidget {
  final _HomeState h;
  const WidgetsPage(this.h, {super.key});

  static const _grad = LinearGradient(
      colors: [Color(0xFF7B3F3F), Color(0xFF4D1D1D)],
      begin: Alignment.topLeft,
      end: Alignment.bottomRight);

  Widget cover(double s, {bool circle = false}) => Container(
        width: s,
        height: s,
        decoration: BoxDecoration(
          shape: circle ? BoxShape.circle : BoxShape.rectangle,
          borderRadius: circle ? null : BorderRadius.circular(s * .2),
          gradient: const LinearGradient(
              colors: [Color(0xFFFF7A3D), Color(0xFF3B6BFF), Color(0xFFE03A5E)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight),
        ),
      );

  Widget ic(IconData i, double s) => Icon(i, color: Colors.white, size: s);

  Widget texts() => const Expanded(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Music',
              style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w600)),
          SizedBox(height: 4),
          Text('Turn on the music',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(color: Colors.white60, fontSize: 15)),
        ]),
      );

  Widget item(int k, Widget preview, String title, String sub) => Column(children: [
        GestureDetector(onTap: () => h.pinWidget(k), child: preview),
        const SizedBox(height: 14),
        Text(title,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w600)),
        const SizedBox(height: 4),
        Text(sub,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 17, color: Colors.black45)),
      ]);

  Widget tileBox(IconData i) => Expanded(
        child: Container(
          margin: const EdgeInsets.all(5),
          decoration: BoxDecoration(
              color: Colors.white24, borderRadius: BorderRadius.circular(16)),
          child: Center(child: ic(i, 30)),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final search = Container(
      height: 220,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(gradient: _grad, borderRadius: BorderRadius.circular(32)),
      child: Column(children: [
        Row(children: [
          cover(64),
          const SizedBox(width: 14),
          texts(),
          ic(Icons.skip_previous, 34),
          const SizedBox(width: 14),
          ic(Icons.play_arrow, 40),
          const SizedBox(width: 14),
          ic(Icons.skip_next, 34),
        ]),
        const Spacer(),
        Container(
          height: 52,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(
              color: Colors.white24, borderRadius: BorderRadius.circular(30)),
          child: Row(children: [
            ic(Icons.search, 26),
            const SizedBox(width: 10),
            const Expanded(
              child: Text('Search Songs, Playlists and Aritists',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: Colors.white70, fontSize: 16)),
            ),
          ]),
        ),
      ]),
    );
    final reco = Container(
      height: 200,
      decoration: BoxDecoration(
          gradient: const LinearGradient(
              colors: [Color(0xFF4A4A4C), Color(0xFF2A2A2C)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight),
          borderRadius: BorderRadius.circular(32)),
      child: Stack(children: [
        Positioned(
          top: 14,
          left: 30,
          right: 30,
          child: Container(
              height: 120,
              decoration: const BoxDecoration(shape: BoxShape.circle, color: Colors.black)),
        ),
        Positioned(
          top: 44,
          left: 70,
          child: cover(62, circle: true),
        ),
        Positioned(
          left: 0,
          right: 0,
          bottom: 0,
          child: Container(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 14),
            decoration: BoxDecoration(
                color: Colors.white12,
                borderRadius: BorderRadius.circular(28)),
            child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Icon(Icons.music_note, color: Colors.white70, size: 26),
              SizedBox(height: 4),
              Text('Daily\nRecommendation',
                  style: TextStyle(
                      color: Colors.white, fontSize: 18, fontWeight: FontWeight.w600)),
            ]),
          ),
        ),
      ]),
    );
    final capsule = Container(
      height: 84,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFF8A3A2D), Color(0xFF5B2420)]),
          borderRadius: BorderRadius.circular(42)),
      child: Row(children: [
        cover(56, circle: true),
        const SizedBox(width: 12),
        Expanded(
          child: Column(mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Music',
                style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w500)),
            const SizedBox(height: 6),
            Row(children: [ic(Icons.pause, 28), const SizedBox(width: 14), ic(Icons.skip_next, 28)]),
          ]),
        ),
      ]),
    );
    final player = Container(
      height: 220,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(gradient: _grad, borderRadius: BorderRadius.circular(32)),
      child: Row(children: [
        Expanded(
          child: Column(children: [
            Row(children: [cover(60), const SizedBox(width: 12), texts()]),
            const Spacer(),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              ic(Icons.skip_previous, 36),
              ic(Icons.play_arrow, 46),
              ic(Icons.skip_next, 36),
            ]),
            const SizedBox(height: 8),
          ]),
        ),
        const SizedBox(width: 10),
        SizedBox(
          width: 150,
          child: Column(children: [
            Expanded(child: Row(children: [tileBox(Icons.music_note), tileBox(Icons.smart_display)])),
            Expanded(child: Row(children: [tileBox(Icons.schedule), tileBox(Icons.star)])),
          ]),
        ),
      ]),
    );
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: ListView(padding: const EdgeInsets.fromLTRB(18, 8, 18, 30), children: [
          SizedBox(
            height: 56,
            child: Stack(alignment: Alignment.center, children: [
              Align(
                alignment: Alignment.centerLeft,
                child: IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back_ios_new, size: 24)),
              ),
              const Text('Home screen widget',
                  style: TextStyle(
                      fontSize: 24, fontWeight: FontWeight.w700, color: Color(0xFF2A0E4A))),
            ]),
          ),
          const SizedBox(height: 14),
          item(0, search, 'Search and play', 'Search for a song and start listening'),
          const SizedBox(height: 26),
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(child: item(1, reco, 'Recommendations', 'Daily picks for you')),
            const SizedBox(width: 18),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(top: 56),
                child: item(2, capsule, 'Capsule player widget',
                    'Quick controls for instant play and pause'),
              ),
            ),
          ]),
          const SizedBox(height: 26),
          item(3, player, 'Recommended player widget', 'Daily song picks for easier listening'),
        ]),
      ),
    );
  }
}
